import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const $ = id => document.getElementById(id);
let currentUnit = 'C', lastWeather = null, currentPlace = {name:'Madurai', country:'India', latitude:9.9252, longitude:78.1198};
const descriptions = {0:'Clear sky',1:'Mainly clear',2:'Partly cloudy',3:'Overcast',45:'Foggy',48:'Rime fog',51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',56:'Freezing drizzle',57:'Freezing drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',66:'Freezing rain',67:'Heavy freezing rain',71:'Light snow',73:'Snow',75:'Heavy snow',77:'Snow grains',80:'Rain showers',81:'Rain showers',82:'Heavy rain showers',85:'Snow showers',86:'Heavy snow showers',95:'Thunderstorm',96:'Thunderstorm with hail',99:'Thunderstorm with hail'};
const emoji = code => code===0?'☀️':[1,2,3].includes(code)?'⛅':[45,48].includes(code)?'🌫️':[51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code)?'🌧️':[71,73,75,77,85,86].includes(code)?'❄️':code>=95?'⛈️':'☁️';
const label = code => descriptions[code] || 'Variable conditions';
const temp = n => currentUnit==='C' ? Math.round(n) : Math.round(n*9/5+32);
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2600)}
function timeLabel(iso){return new Date(iso).toLocaleTimeString([], {hour:'numeric'});}
function dateLabel(iso){return new Date(iso+'T12:00:00').toLocaleDateString([], {weekday:'short'});}
async function getWeather(place){
  $('condition').textContent='Fetching conditions...';
  try{
    const r=await fetch(`/api/weather?lat=${place.latitude}&lon=${place.longitude}`);
    const data=await r.json(); if(!r.ok) throw new Error(data.error||'Weather unavailable');
    lastWeather=data;currentPlace=place;render(data,place);setAtmosphere(data.current.weather_code,data.current.is_day);
  }catch(e){toast(e.message)}
}
function render(data,place){
  const c=data.current, d=data.daily;
  $('placeName').textContent=[place.name,place.country].filter(Boolean).join(', ');
  $('localTime').textContent='Local time · '+new Date().toLocaleString([], {weekday:'long',hour:'numeric',minute:'2-digit'});
  $('temperature').textContent=temp(c.temperature_2m);$('degree').textContent='°'+currentUnit;
  $('condition').textContent=label(c.weather_code);$('feels').textContent=temp(c.apparent_temperature)+'°';
  $('humidity').textContent=c.relative_humidity_2m+'%';$('wind').textContent=Math.round(c.wind_speed_10m)+' km/h';
  $('rain').textContent=(c.precipitation??0).toFixed(1)+' mm';$('cloud').textContent=c.cloud_cover+'%';
  $('updated').textContent='Updated just now · '+(data.timezone||'Local timezone');
  $('sceneCondition').textContent=label(c.weather_code).toUpperCase();$('weatherEmoji').textContent=emoji(c.weather_code);
  $('sceneTitle').textContent=label(c.weather_code);$('sceneSubtitle').textContent=`${temp(c.temperature_2m)}° · ${c.relative_humidity_2m}% humidity`;
  const now=new Date();let start=data.hourly.time.findIndex(t=>new Date(t)>=now);if(start<0)start=0;
  $('hourlyList').innerHTML=data.hourly.time.slice(start,start+12).map((t,i)=>{let k=start+i;return `<div class="hour-card"><small>${i===0?'Now':timeLabel(t)}</small><div class="hour-icon">${emoji(data.hourly.weather_code[k])}</div><strong>${temp(data.hourly.temperature_2m[k])}°</strong><div class="rain-chance">${data.hourly.precipitation_probability[k]??0}% rain</div></div>`}).join('');
  $('dailyGrid').innerHTML=d.time.map((day,i)=>`<div class="day-card"><small>${i===0?'Today':dateLabel(day)}</small><div class="day-icon">${emoji(d.weather_code[i])}</div><strong>${label(d.weather_code[i])}</strong><div class="range">${temp(d.temperature_2m_max[i])}° / ${temp(d.temperature_2m_min[i])}°</div><small>${d.precipitation_probability_max[i]??0}% rain</small></div>`).join('');
}
$('searchBtn').addEventListener('click',async()=>{
  const city=$('cityInput').value.trim();if(!city)return toast('Enter a city name');
  $('searchBtn').textContent='Searching...';
  try{const r=await fetch('/api/search?city='+encodeURIComponent(city));const p=await r.json();if(!r.ok)throw new Error(p.error);await getWeather(p)}
  catch(e){toast(e.message)}finally{$('searchBtn').innerHTML='Explore <span>↗</span>'}
});
$('cityInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('searchBtn').click()});
$('locationBtn').addEventListener('click',()=>{
  if(!navigator.geolocation)return toast('Location is not supported by this browser');
  navigator.geolocation.getCurrentPosition(async pos=>{const p={latitude:pos.coords.latitude,longitude:pos.coords.longitude,name:'Your location',country:''};await getWeather(p)},()=>toast('Please allow location access in your browser'),{enableHighAccuracy:true,timeout:10000});
});
$('unitToggle').addEventListener('click',()=>{currentUnit=currentUnit==='C'?'F':'C';$('unitToggle').innerHTML=currentUnit==='C'?'°C <span>/ °F</span>':'°F <span>/ °C</span>';if(lastWeather)render(lastWeather,currentPlace)});

// Three.js particle atmosphere: animated particles are a visual representation of the forecast.
let scene,camera,renderer,particles,particleMaterial,kind='cloud',lightning=0;
function initScene(){
  const canvas=$('weatherCanvas');scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(55,1,.1,100);camera.position.z=7;
  renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  const count=kind==='rain'?1500:kind==='snow'?650:420;const positions=new Float32Array(count*3);
  for(let i=0;i<count;i++){positions[i*3]=(Math.random()-.5)*13;positions[i*3+1]=(Math.random()-.5)*9;positions[i*3+2]=(Math.random()-.5)*5}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
  particleMaterial=new THREE.PointsMaterial({color:0xdaf6ff,size:kind==='rain'?.035:.055,transparent:true,opacity:kind==='cloud'?.3:.75});
  particles=new THREE.Points(geo,particleMaterial);scene.add(particles);resize();animate();
}
function resize(){if(!renderer)return;const w=$('scene').clientWidth,h=$('scene').clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function setAtmosphere(code,isDay){
  if(!scene)return;
  kind=code>=95?'storm':[51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code)?'rain':[71,73,75,77,85,86].includes(code)?'snow':[45,48].includes(code)?'fog':[0,1].includes(code)?'sun':'cloud';
  const colors={sun:0xf7d78b,cloud:0xd9efff,rain:0xb7e9ff,storm:0xc6d5ff,snow:0xffffff,fog:0xd7e0e8};
  particleMaterial.color.setHex(colors[kind]);particleMaterial.size=kind==='rain'?.035:kind==='snow'?.075:.055;
  particleMaterial.opacity=kind==='cloud'?.22:kind==='fog'?.12:.72;
  $('scene').style.background=kind==='sun'?'linear-gradient(180deg,#3d789b,#8bc3d1 58%,#244c60)':kind==='storm'?'linear-gradient(180deg,#111d35,#344b65 65%,#15283a)':kind==='rain'?'linear-gradient(180deg,#244762,#668a9a 60%,#18384c)':kind==='snow'?'linear-gradient(180deg,#7898ad,#c1d5df 60%,#526e80)':'linear-gradient(180deg,#183c5d,#386d8c 57%,#18364c)';
}
function animate(){
  requestAnimationFrame(animate);if(!renderer)return;
  const a=particles.geometry.attributes.position.array;
  for(let i=0;i<a.length;i+=3){
    if(kind==='rain'||kind==='storm'){a[i+1]-=.055;a[i]+=.008;if(a[i+1]<-4.5){a[i+1]=4.5;a[i]=(Math.random()-.5)*13}}
    else if(kind==='snow'){a[i+1]-=.012;a[i]+=Math.sin(Date.now()*.001+i)*.0015;if(a[i+1]<-4.5)a[i+1]=4.5}
    else {a[i+1]+=Math.sin(Date.now()*.0004+i)*.0008;a[i]+=.0015;if(a[i]>6.5)a[i]=-6.5}
  }
  particles.geometry.attributes.position.needsUpdate=true;particles.rotation.y=Math.sin(Date.now()*.0002)*.035;
  if(kind==='storm'&&Math.random()>.992){$('scene').style.filter='brightness(1.7)';setTimeout(()=>$('scene').style.filter='',100)}
  renderer.render(scene,camera);
}
window.addEventListener('resize',resize);initScene();getWeather(currentPlace);
